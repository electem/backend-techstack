export class Course {
  id?: any
  xyz?: string
  abc?: string
}
