import { Component, OnInit } from '@angular/core'
import { StudentService } from 'src/app/services/student.service'
import { ActivatedRoute, Router } from '@angular/router'
@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css'],
})
export class StudentDetailsComponent implements OnInit {
  currentStudent: any = {
    title: '',
    description: '',
    published: false,
  }
  message = ''
  constructor(
    private studentService: StudentService,
    private route: ActivatedRoute,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.getStudent(this.route.snapshot.params.id)
  }

  getStudent(id: string): void {
    this.studentService.get(id).subscribe(
      (data) => {
        this.currentStudent = data
        console.log(data)
      },
      (error) => {
        console.log(error)
      },
    )
  }

  updateStudent(): void {
    this.studentService
      .update(this.currentStudent.id, this.currentStudent)
      .subscribe(
        (response) => {
          console.log(response)
          this.router.navigate(['/student-list'])
          this.message = response.message
            ? response.message
            : 'This Student was updated successfully!'
        },
        (error) => {
          console.log(error)
        },
      )
  }

  deleteStudent(): void {
    this.studentService.delete(this.currentStudent.id).subscribe(
      (response) => {
        console.log(response)
        this.router.navigate(['/student-list'])
      },
      (error) => {
        console.log(error)
      },
    )
  }
}
